#pragma once
class String
{
private:
    char *data;
public:

String();
void CopyString(char *des,const char * source);
String(const char* n);
String(const String &other);
String &operator=(const String &s);
int getlength(const char* str);
void Setstring(const char*n);
const char* getString()const;
int length()const;
char at(const int index) const;
void clear();
void display()const;
~String();

    
};


