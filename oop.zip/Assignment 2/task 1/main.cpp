#include <iostream>
#include "String.h"
using namespace std;
int main()
{
    char arr[500];
    cout << "please enter some string: ";
    cin.getline(arr, 500);
    String s1(arr);
    s1.display();
    String s2 = s1; // showing copy constrct is doing deep cpy
    s1.display();
    s2.display(); // s2 is same as previous
    String s4("Checking assig operator");
    s4.display();
    s2 = s4;
    s2.display(); // all req things completed!
    cout << "Enter Index to check: ";
    int idx;
    cin >> idx;
    while (cin.fail() || idx < 0)
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Invalid please enter again: ";
        cin >> idx;
    }
    char ret = s1.at(idx);
    cout << ret;
}