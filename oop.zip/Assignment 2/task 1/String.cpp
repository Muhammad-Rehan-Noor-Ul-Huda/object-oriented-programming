#include "String.h"
#include <iostream>
using namespace std;

void String::CopyString(char *dest, const char *sorc)
{
    int i = 0;
    while (sorc[i] != '\0')
    {
        dest[i] = sorc[i];
        i++;
    }
    dest[i] = '\0';
}
String::String()
{
    data = new char[8];
    CopyString(data, "Unknown");
}
String::String(const char *str)
{

    data = nullptr;
    Setstring(str);
}
void String::Setstring(const char *str)
{
    if (data != nullptr)
    {
        delete[] data;
        data = nullptr;
    }
    if (str != nullptr)
    {

        int len = getlength(str) + 1;
        data = new char[len];
        CopyString(data, str);
    }
    else{
        data=new char[1];
        data[0]='\0';
    }
}
int String::length() const
{
    if(data==nullptr){
        return 0;
    }
    int i = 0;
    while (data[i] != '\0')
    {
        i++;
    }
    return i;
}
String & String::operator=(const String &str)
{  
    if (this == &str)
    {
        cout << "Self assignment" << endl;
        return *this;
    }

    int len = getlength(str.data) + 1;

    if (this->data != nullptr)
    {
        delete[] data;
        data = nullptr;
    }

    data = new char[len];
    CopyString(data, str.data);

    return *this;
}
int String::getlength(const char *str)
{
    if(str==nullptr){
        return 0;
    }
    int i = 0;
    while (str[i] != '\0')
    {
        i++;
    }
    return i;
}
const char *String::getString() const
{
    return data;
}
char String::at(const int index) const
{
    int len = length();
    if (len == 0)
    {
        cout << "Nothing Found in string";
        return '\0';
    }                                                   //a b c d 
    if (index > (len - 1) || index<0) 
    {
        cout << "Wrong index!";
        return '\0';
    }
    return data[index];
}
void String::clear()
{
    if (data != nullptr)
    {
        delete[] data;
        data = nullptr;
    }
}
String::~String()
{
    if (data != nullptr)
    {
        delete[] data;
        data = nullptr;
    }
}
String::String(const String &other)
{
    data = nullptr;
    Setstring(other.data);
}
void String::display() const
{
    cout << data << endl;
}
