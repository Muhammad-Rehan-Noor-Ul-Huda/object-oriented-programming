class Date
{
    int day;
    int month;
    int year;
    const static char *defaultDate;

public:
    Date(int d = 1, int m = 1, int y = 1);
    void setDay(const int d);
    void setMonth(const int m);
    void setYear(const int y);
    const int getDay() const;
    const int getMonth() const;
    const int getYear() const;
    void addDay(const int d);
    void addMonth(const int m);
    void addYear(const int y);
    void display() const;
    static const char *getStatic();
    ~Date();
};
 bool leapYear(const int a);