#include "date.h"
#include <iostream>
using namespace std;
const char *Date::defaultDate = "01/01/2000";
Date::Date(int d, int m, int y)
{
    day = 1;
    month = 1;
    year = 1;
    if (y > 0)
    {
        setYear(y);
    }
    else
    {
        year = 1;
    }
    if (m > 0)
    {
        setMonth(m);
    }
    else
    {
        month = 1;
    }
    if (d > 0)
    {
        setDay(d);
    }
    else
    {
        day = 1;
    }
}
const int Date::getDay() const
{
    return day;
}
const int Date::getMonth() const
{
    return month;
}
const int Date::getYear() const
{
    return year;
}
bool leapYear(const int a)
{
    if ((a % 4 == 0 && a % 100 != 0) || (a % 400 == 0))
    {
        return true;
    }
    return false;
}
void Date::setYear(const int y)
{
    if (y > 0)
    {
        year = y;
        setDay(day);
    }
}
void Date::setMonth(const int m)
{
    int temp = m;
    if (temp > 0)
    {
        if (temp > 12)
        {
            if (temp % 12 == 0)
            {
                temp -= 1;
                year = year + temp / 12;
                temp = temp % 12 + 1;
            }
            else
            {
                year = year + temp / 12;
                temp = temp % 12;
            }
        }
        month = temp;
    }
    else
    {
        month = 1;
    }
    setDay(day);
}
void Date::setDay(const int num)
{
    int d = num;
    if (d > 0)
    {
        int maxdays;
        while (d > 28)
        {
            if (month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
            {
                maxdays = 31;
            }
            else if (month == 2)
            {
                if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
                {
                    maxdays = 29;
                }
                else
                {
                    maxdays = 28;
                }
            }
            else
            {
                maxdays = 30;
            }
            if ((d - maxdays) > 0)
            {
                d = d - maxdays;
                if ((month + 1) > 12)
                {
                    year++;
                    month = 1;
                }
                else
                {
                    month++;
                }
            }
            else
            {
                break;
            }
        }
        day = d;
    }
    else
    {
        day = 1;
    }
}
void Date::addYear(const int y)
{
    if (y > 0)
    {

        setYear(year + y);
    }
}
void Date::addMonth(const int mon)
{
    if (mon > 0)
    {
        setMonth(mon + month);
    }
}
void Date::addDay(const int num)
{
    if (num > 0)
    {
        setDay(num + day);
    }
    else
    {
        day = 1;
    }
}
void Date::display() const
{
    cout << "Date: " << day << " / " << month << " / " << year << endl;
}
const char *Date::getStatic()
{
    return defaultDate;
}
Date::~Date()
{
    cout << "Destroying....." << endl;
}