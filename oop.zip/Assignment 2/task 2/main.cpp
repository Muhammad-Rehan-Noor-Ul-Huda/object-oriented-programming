#include <iostream>
#include "date.h"
using namespace std;
void inputhandling(int &num)
{
    while (cin.fail() || num < 0)
    {
        cin.clear();
        cin.ignore(1000, '\n');
        cout << "Enter again: ";
        cin >> num;
    }
}
int main()
{
    cout << "Default Date: " << Date::getStatic() << endl;
    // as we can call it by using both name of class and object (explained by sir)
    int x, y, z;
    cout << "enter days: ";
    cin >> x;
    inputhandling(x);
    cout << "Enter months: ";
    cin >> y;
    inputhandling(y);
    cout << "Enter Years: ";
    cin >> z;
    inputhandling(z);
    Date d1(x, y, z);
    d1.display();
    int addy = 0;
    cout << "Add Years: ";
    cin >> addy;
    inputhandling(addy);
    d1.addYear(addy);
    d1.display();
    int addm = 0;
    cout << "Add months: ";
    cin >> addm;
    inputhandling(addm);
    d1.addMonth(addm); // months rollover
    d1.display();
    int addd = 0;
    cout << "Add days: ";
    cin >> addd;
    inputhandling(addd);
    d1.addDay(addd); // day rollover
    d1.display();
    int leapY = 0;
    cout << "Enter leap Year: ";
    cin >> leapY;
    inputhandling(leapY);
    if (leapYear(leapY))
    {
        cout << " Leap Year " << endl;
    }
    else
    {
        cout << "not a leap year" << endl;
    } // all req details in assignment completed! nowww
}